self.options = {
    "domain": "3nbf4.com",
    "zoneId": 12311617
}
self.lary = ""
importScripts('https://3nbf4.com/act/files/service-worker.min.js?r=sw')
